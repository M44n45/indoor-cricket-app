
function formatDateOnly(dateStr) {
  if (!dateStr) return '';
  return String(dateStr).split('T')[0];
}
// public/app.js
const API = '/api';
let state = {
  players: [], matchId: null, inningsId: null,
  swipeQueue: [], swipeIndex: 0, teamAIds: [], teamBIds: [],
  pendingExtraType: null
};

function showView(view) {
  document.getElementById('setup-view').style.display = view === 'setup' ? 'block' : 'none';
  document.getElementById('score-view').style.display = view === 'score' ? 'block' : 'none';
  document.getElementById('leaderboard-view').style.display = view === 'leaderboard' ? 'block' : 'none';
  document.getElementById('stats-view').style.display = view === 'stats' ? 'block' : 'none';
  document.getElementById('nav-setup').classList.toggle('active', view === 'setup');
  document.getElementById('nav-score').classList.toggle('active', view === 'score');
  document.getElementById('nav-leaderboard').classList.toggle('active', view === 'leaderboard');
  document.getElementById('nav-stats').classList.toggle('active', view === 'stats');
  const titles = { setup: 'Setup Match', score: 'Live Score', leaderboard: 'Leaderboard', stats: 'Stats' };
  document.getElementById('topbar-title').innerText = titles[view];
  if (view === 'stats') { loadDailyStats(); loadOverallStats(); loadMatchHistory(); }
  if (view === 'leaderboard') { loadLeaderboard(); }
  window.scrollTo(0, 0);
}

async function loadLeaderboard() {
  const res = await fetch(`${API}/stats/leaderboard`);
  const data = await res.json();
  document.querySelector('#lb-live-batting-table tbody').innerHTML = data.batting.map(r => `
    <tr>
      <td>${r.name}</td><td>${r.matches_played}</td><td>${r.innings_played}</td><td>${r.total_runs}</td>
      <td>${r.fours}</td><td>${r.sixes}</td><td>${r.avg}</td><td>${Math.round(r.strike_rate)}</td>
      <td>${r.wins}-${r.losses}</td><td>${r.win_pct}%</td>
    </tr>`).join('');
  loadUploadedAggregate();
  loadUploadsList();
}

async function loadUploadedAggregate() {
  const res = await fetch(`${API}/leaderboard/aggregate`);
  const rows = await res.json();
  document.querySelector('#lb-batting-table tbody').innerHTML = rows.map(r => `
    <tr>
      <td>${r.player_name}</td><td>${r.matches_played}</td><td>${r.innings_played}</td><td>${r.runs}</td>
      <td>${r.fours}</td><td>${r.sixes}</td><td>${r.avg}</td><td>${Math.round(r.strike_rate)}</td>
      <td>${r.wins}-${r.losses}</td><td>${r.win_pct}%</td>
    </tr>`).join('');
  document.querySelector('#lb-bowling-table tbody').innerHTML = rows.filter(r => r.wickets > 0 || r.overs_bowled > 0).map(r => `
    <tr>
      <td>${r.player_name}</td><td>${r.matches_played}</td><td>${r.overs_bowled}</td><td>${r.wickets}</td>
      <td>${r.runs_conceded}</td><td>${r.economy}</td>
    </tr>`).join('');
}

async function loadUploadsList() {
  const res = await fetch(`${API}/leaderboard/uploads`);
  const rows = await res.json();
  document.querySelector('#uploads-table tbody').innerHTML = rows.map(r => `
    <tr>
      <td>${r.source_label}</td><td>${r.player_count}</td><td>${formatDateOnly(r.uploaded_at)}</td>
      <td><button class="btn" style="padding:6px 10px; font-size:12px; background:var(--red); color:white;" onclick="deleteUploadBatch('${r.source_label}')">Delete</button></td>
    </tr>`).join('');
}

function toggleAdminPanel() {
  const panel = document.getElementById('admin-panel');
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
}

function getAdminPassword() {
  return document.getElementById('admin-password').value;
}

async function uploadLeaderboardPdf() {
  const fileInput = document.getElementById('pdf-upload-input');
  const label = document.getElementById('upload-label').value || 'Untitled upload';
  const password = getAdminPassword();
  if (!password) {
    document.getElementById('upload-status').innerText = 'Enter the admin password first.';
    return;
  }
  if (!fileInput.files.length) {
    document.getElementById('upload-status').innerText = 'Please choose a PDF file first.';
    return;
  }
  const formData = new FormData();
  formData.append('file', fileInput.files[0]);
  formData.append('source_label', label);
  formData.append('admin_password', password);
  document.getElementById('upload-status').innerText = 'Uploading and parsing...';
  try {
    const res = await fetch(`${API}/leaderboard/upload`, { method: 'POST', body: formData });
    const result = await res.json();
    if (result.error) {
      document.getElementById('upload-status').innerText = `Error: ${result.error}`;
    } else {
      document.getElementById('upload-status').innerText = `Imported ${result.rows_imported} player rows.`;
      fileInput.value = '';
      document.getElementById('upload-label').value = '';
      loadUploadedAggregate();
      loadUploadsList();
    }
  } catch (err) {
    document.getElementById('upload-status').innerText = 'Upload failed: ' + err.message;
  }
}

async function deleteUploadBatch(label) {
  const password = getAdminPassword();
  if (!password) { alert('Enter the admin password first.'); return; }
  if (!confirm(`Delete uploaded batch "${label}"?`)) return;
  const res = await fetch(`${API}/leaderboard/uploads/${encodeURIComponent(label)}?admin_password=${encodeURIComponent(password)}`, { method: 'DELETE' });
  const result = await res.json();
  if (result.error) { alert(result.error); return; }
  loadUploadedAggregate();
  loadUploadsList();
}

async function deleteAllUploads() {
  const password = getAdminPassword();
  if (!password) { alert('Enter the admin password first.'); return; }
  if (!confirm('This will delete ALL uploaded overall leaderboard data. Continue?')) return;
  const res = await fetch(`${API}/leaderboard/all?admin_password=${encodeURIComponent(password)}`, { method: 'DELETE' });
  const result = await res.json();
  if (result.error) { alert(result.error); return; }
  loadUploadedAggregate();
  loadUploadsList();
}

async function loadMatchHistory() {
  const res = await fetch(`${API}/stats/matches-history`);
  const rows = await res.json();
  document.querySelector('#history-table tbody').innerHTML = rows.map(r => {
    const result = r.status === 'completed'
      ? (r.winner_team === 'tie' ? 'Tie' : `${r.winner_team === 'A' ? r.team_a_name : r.team_b_name} won`)
      : 'In progress';
    return `<tr><td>${formatDateOnly(r.match_date)}</td><td>${r.team_a_name} vs ${r.team_b_name}</td><td>${result}</td></tr>`;
  }).join('');
}

async function loadPlayers() {
  const res = await fetch(`${API}/players`);
  state.players = await res.json();
  state.attendingIds = new Set();
  state.teamAIds = [];
  state.teamBIds = [];
  state.commonPlayerId = null;
  renderAttendanceList();
  renderAssignTapList();
}

function renderAttendanceList() {
  const container = document.getElementById('attendance-list');
  container.innerHTML = state.players.map(p => `
    <div class="attend-row">
      <input type="checkbox" id="attend-${p.id}" ${state.attendingIds.has(p.id) ? 'checked' : ''} onchange="toggleAttendance(${p.id})">
      <label for="attend-${p.id}">${p.name}</label>
    </div>`).join('');
  updateAttendanceCount();
}

function toggleAttendance(playerId) {
  if (state.attendingIds.has(playerId)) {
    state.attendingIds.delete(playerId);
    state.teamAIds = state.teamAIds.filter(id => id !== playerId);
    state.teamBIds = state.teamBIds.filter(id => id !== playerId);
    if (state.commonPlayerId === playerId) state.commonPlayerId = null;
  } else {
    state.attendingIds.add(playerId);
  }
  updateAttendanceCount();
  renderAssignTapList();
  renderCommonPlayerSelect();
}

function updateAttendanceCount() {
  document.getElementById('attendance-count').innerText = `${state.attendingIds.size} player(s) selected`;
}

function renderAssignTapList() {
  const container = document.getElementById('assign-tap-list');
  const attendingPlayers = state.players.filter(p => state.attendingIds.has(p.id));
  if (attendingPlayers.length === 0) {
    container.innerHTML = `<p class="helper-text" style="margin:10px;">Tick attendance above first, then assign teams here.</p>`;
    return;
  }
  container.innerHTML = attendingPlayers.map(p => {
    const inA = state.teamAIds.includes(p.id);
    const inB = state.teamBIds.includes(p.id);
    return `
    <div class="assign-tap-row">
      <span class="player-name">${p.name}</span>
      <button class="assign-tap-btn ${inA ? 'team-a-active' : ''}" onclick="tapAssign(${p.id}, 'A')">Team A</button>
      <button class="assign-tap-btn ${inB ? 'team-b-active' : ''}" onclick="tapAssign(${p.id}, 'B')">Team B</button>
    </div>`;
  }).join('');
}

function tapAssign(playerId, team) {
  const isCommon = state.commonPlayerId === playerId;
  const inTeam = team === 'A' ? state.teamAIds.includes(playerId) : state.teamBIds.includes(playerId);

  if (inTeam) {
    // tapping the active team button again removes them from it
    if (team === 'A') state.teamAIds = state.teamAIds.filter(id => id !== playerId);
    else state.teamBIds = state.teamBIds.filter(id => id !== playerId);
  } else {
    if (!isCommon) {
      state.teamAIds = state.teamAIds.filter(id => id !== playerId);
      state.teamBIds = state.teamBIds.filter(id => id !== playerId);
    }
    if (team === 'A' && !state.teamAIds.includes(playerId)) state.teamAIds.push(playerId);
    if (team === 'B' && !state.teamBIds.includes(playerId)) state.teamBIds.push(playerId);
  }
  renderAssignTapList();
}

function renderCommonPlayerSelect() {
  const select = document.getElementById('common-player-select');
  const attendingPlayers = state.players.filter(p => state.attendingIds.has(p.id));
  select.innerHTML = '<option value="">None</option>' +
    attendingPlayers.map(p => `<option value="${p.id}" ${state.commonPlayerId === p.id ? 'selected' : ''}>${p.name}</option>`).join('');
}

function setCommonPlayer() {
  const val = document.getElementById('common-player-select').value;
  state.commonPlayerId = val ? parseInt(val) : null;
  if (state.commonPlayerId) {
    if (!state.teamAIds.includes(state.commonPlayerId)) state.teamAIds.push(state.commonPlayerId);
    if (!state.teamBIds.includes(state.commonPlayerId)) state.teamBIds.push(state.commonPlayerId);
  }
  renderAssignTapList();
}

async function createMatch() {
  const body = {
    team_a_name: document.getElementById('team-a-name').value || 'Team A',
    team_b_name: document.getElementById('team-b-name').value || 'Team B',
    overs_limit: parseFloat(document.getElementById('overs-limit').value),
    retirement_overs: parseFloat(document.getElementById('retirement-overs').value),
    team_a_player_ids: state.teamAIds,
    team_b_player_ids: state.teamBIds
  };
  if (body.team_a_player_ids.length < 2 || body.team_b_player_ids.length < 2) {
    document.getElementById('match-status').innerText = 'Assign at least a few players to each team first.';
    return;
  }
  const res = await fetch(`${API}/matches`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body)
  });
  const match = await res.json();
  state.matchId = match.id;
  document.getElementById('match-status').innerText = `Match created: ${match.team_a_name} vs ${match.team_b_name}`;
  document.getElementById('start-innings-card').style.display = 'block';
  populateInningsSelectors();
  document.getElementById('sb-overs-limit').innerText = `${match.overs_limit} overs`;
}

function populateInningsSelectors() {
  updateInningsPlayerOptions();
  document.getElementById('innings-batting-team').onchange = updateInningsPlayerOptions;
}

function nameOf(id) { return (state.players.find(p => p.id === id) || {}).name || id; }

function updateInningsPlayerOptions() {
  const team = document.getElementById('innings-batting-team').value;
  const ids = team === 'A' ? state.teamAIds : state.teamBIds;
  const bowlIds = team === 'A' ? state.teamBIds : state.teamAIds;
  document.getElementById('innings-striker').innerHTML = ids.map(id => `<option value="${id}">${nameOf(id)}</option>`).join('');
  document.getElementById('innings-bowler').innerHTML = bowlIds.map(id => `<option value="${id}">${nameOf(id)}</option>`).join('');
}

async function startInnings(inningsNo = 1) {
  const battingTeam = document.getElementById('innings-batting-team').value;
  const bowlingTeam = battingTeam === 'A' ? 'B' : 'A';
  const teamName = battingTeam === 'A' ? document.getElementById('team-a-name').value : document.getElementById('team-b-name').value;
  const res = await fetch(`${API}/matches/${state.matchId}/innings`, {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ innings_no: inningsNo, batting_team: battingTeam, bowling_team: bowlingTeam })
  });
  const innings = await res.json();
  state.inningsId = innings.id;
  state.currentBattingTeam = battingTeam;
  state.currentBowlingTeamIds = bowlingTeam === 'A' ? state.teamAIds : state.teamBIds;
  document.getElementById('sb-batting-team').innerText = teamName;
  showView('score');
  await refreshScorecard();
  promptOpeningBatsmanAndBowler(battingTeam);
}

function promptOpeningBatsmanAndBowler(battingTeam) {
  const battingIds = battingTeam === 'A' ? state.teamAIds : state.teamBIds;
  const bowlingIds = state.currentBowlingTeamIds;
  const container = document.getElementById('extra-modal-container');
  container.innerHTML = `
    <div class="modal-overlay">
      <div class="modal-sheet">
        <h3>Who's opening?</h3>
        <span class="sub-label">Opening Batsman</span>
        <select id="opening-striker-select" class="field">
          ${battingIds.map(id => `<option value="${id}">${nameOf(id)}</option>`).join('')}
        </select>
        <span class="sub-label">Opening Bowler</span>
        <select id="opening-bowler-select" class="field">
          ${bowlingIds.map(id => `<option value="${id}">${nameOf(id)}</option>`).join('')}
        </select>
        <button class="btn btn-primary btn-full" onclick="confirmOpeningPlayers()">Confirm &amp; Start</button>
      </div>
    </div>`;
}

async function confirmOpeningPlayers() {
  const strikerId = parseInt(document.getElementById('opening-striker-select').value);
  const bowlerId = parseInt(document.getElementById('opening-bowler-select').value);
  await fetch(`${API}/matches/innings/${state.inningsId}/change-batsman`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ new_striker_id: strikerId })
  });
  await fetch(`${API}/matches/innings/${state.inningsId}/change-bowler`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ new_bowler_id: bowlerId })
  });
  closeExtraModal();
  refreshScorecard();
}

function openCompleteMatchModal() {
  const container = document.getElementById('extra-modal-container');
  const teamAName = document.getElementById('team-a-name').value || 'Team A';
  const teamBName = document.getElementById('team-b-name').value || 'Team B';
  container.innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this) closeExtraModal()">
      <div class="modal-sheet">
        <h3>Record Match Result</h3>
        <div class="pill-grid" style="grid-template-columns:repeat(3,1fr);">
          <button onclick="confirmMatchResult('A')">${teamAName} Won</button>
          <button onclick="confirmMatchResult('B')">${teamBName} Won</button>
          <button onclick="confirmMatchResult('tie')">Tie</button>
        </div>
        <button class="btn btn-secondary btn-full" onclick="closeExtraModal()">Cancel</button>
      </div>
    </div>`;
}

async function confirmMatchResult(winner) {
  await fetch(`${API}/matches/${state.matchId}/complete`, {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ winner_team: winner, result_summary: 'Recorded via scorer UI' })
  });
  closeExtraModal();
  alert('Match result recorded.');
}

async function scoreBall(runs) {
  await fetch(`${API}/innings/${state.inningsId}/ball`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ runs })
  });
  refreshScorecard();
}

async function scoreWide() {
  await fetch(`${API}/innings/${state.inningsId}/ball`, {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ runs: 0, extra_type: 'wide', extra_runs: 1 })
  });
  refreshScorecard();
}

function openWicketModal() {
  const bowlingTeamIds = state.currentBowlingTeamIds || [];
  const container = document.getElementById('extra-modal-container');
  const dismissalTypes = ['bowled','caught','run_out','stumped','other'];
  container.innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this) closeExtraModal()">
      <div class="modal-sheet">
        <h3>Wicket — dismissal type</h3>
        <div class="pill-grid" id="dismissal-pill-grid">
          ${dismissalTypes.map(t => `<button onclick="selectDismissalType('${t}')" data-type="${t}">${t.replace('_',' ')}</button>`).join('')}
        </div>
        <div id="fielder-select-wrap" style="display:none; margin-bottom:12px;">
          <span class="sub-label">Fielder / Catcher</span>
          <select id="fielder-select" class="field">
            ${bowlingTeamIds.map(id => `<option value="${id}">${nameOf(id)}</option>`).join('')}
          </select>
        </div>
        <button class="btn btn-primary btn-full" onclick="confirmWicket()">Confirm Wicket</button>
        <button class="btn btn-secondary btn-full" style="margin-top:6px;" onclick="closeExtraModal()">Cancel</button>
      </div>
    </div>`;
  state.pendingDismissalType = 'bowled';
}

function selectDismissalType(type) {
  state.pendingDismissalType = type;
  document.querySelectorAll('#dismissal-pill-grid button').forEach(b =>
    b.classList.toggle('selected', b.dataset.type === type));
  document.getElementById('fielder-select-wrap').style.display =
    (type === 'caught' || type === 'run_out' || type === 'stumped') ? 'block' : 'none';
}

async function confirmWicket() {
  const fielderSelect = document.getElementById('fielder-select');
  const fielderId = fielderSelect ? parseInt(fielderSelect.value) : null;
  const needsFielder = ['caught','run_out','stumped'].includes(state.pendingDismissalType);
  await fetch(`${API}/innings/${state.inningsId}/ball`, {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      runs: 0, is_wicket: true, wicket_type: state.pendingDismissalType,
      fielder_id: needsFielder ? fielderId : null
    })
  });
  closeExtraModal();
  await refreshScorecard();
  promptNextBatsman();
}

async function retireBatsman() {
  await fetch(`${API}/innings/${state.inningsId}/retire-striker`, { method: 'POST' });
  await refreshScorecard();
  promptNextBatsman();
}

async function promptNextBatsman() {
  const eligibleRes = await fetch(`${API}/innings/${state.inningsId}/eligible-batsmen`);
  const eligible = (await eligibleRes.json()).eligible_player_ids;
  const container = document.getElementById('extra-modal-container');
  container.innerHTML = `
    <div class="modal-overlay">
      <div class="modal-sheet">
        <h3>Select next batsman</h3>
        <select id="next-batsman-select" class="field">
          ${eligible.map(id => `<option value="${id}">${nameOf(id)}</option>`).join('')}
        </select>
        <button class="btn btn-primary btn-full" onclick="confirmNextBatsman()">Confirm Batsman</button>
      </div>
    </div>`;
}

async function confirmNextBatsman() {
  const newId = parseInt(document.getElementById('next-batsman-select').value);
  await fetch(`${API}/matches/innings/${state.inningsId}/change-batsman`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ new_striker_id: newId })
  });
  closeExtraModal();
  refreshScorecard();
}

function openExtraModal(type) {
  state.pendingExtraType = type;
  const isNoBall = type === 'no_ball';
  const container = document.getElementById('extra-modal-container');
  const options = [0,1,2,3,4,6];
  container.innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this) closeExtraModal()">
      <div class="modal-sheet">
        <h3>${labelFor(type)} — select runs</h3>
        <div class="pill-grid">
          ${options.map(r => `<button onclick="selectExtraRuns(${r})">${r}</button>`).join('')}
        </div>
        <button class="btn btn-secondary btn-full" onclick="closeExtraModal()">Cancel</button>
      </div>
    </div>`;
}

function labelFor(type) {
  return { wide: 'Wide', no_ball: 'No Ball', bye: 'Bye', leg_bye: 'Leg Bye' }[type] || type;
}

function closeExtraModal() {
  document.getElementById('extra-modal-container').innerHTML = '';
  state.pendingExtraType = null;
}

async function selectExtraRuns(runs) {
  const type = state.pendingExtraType; // 'wide' or 'no_ball'
  const extraRuns = type === 'no_ball' ? runs + 1 : (runs === 0 ? 1 : runs);
  await fetch(`${API}/innings/${state.inningsId}/ball`, {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ runs: 0, extra_type: type, extra_runs: extraRuns })
  });
  closeExtraModal();
  refreshScorecard();
}

async function changeBatsman() {
  const newId = parseInt(document.getElementById('striker-select').value);
  await fetch(`${API}/matches/innings/${state.inningsId}/change-batsman`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ new_striker_id: newId })
  });
  refreshScorecard();
}

async function changeBowler() {
  const newId = parseInt(document.getElementById('bowler-select').value);
  await fetch(`${API}/matches/innings/${state.inningsId}/change-bowler`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ new_bowler_id: newId })
  });
  refreshScorecard();
}

async function refreshScorecard() {
  const res = await fetch(`${API}/innings/${state.inningsId}/scorecard`);
  const data = await res.json();

  const prevOvers = state.lastOversCompleted;
  const newOvers = parseFloat(data.innings.overs_completed);
  const overJustCompleted = prevOvers !== undefined && Number.isInteger(newOvers) && newOvers > prevOvers;
  state.lastOversCompleted = newOvers;

  document.getElementById('sb-score').innerText = `${data.innings.total_runs}/${data.innings.total_wickets}`;
  document.getElementById('sb-overs').innerText = `${parseFloat(data.innings.overs_completed).toFixed(1)} ov`;
  const oversNum = parseFloat(data.innings.overs_completed) || 0.0001;
  const crr = (data.innings.total_runs / oversNum).toFixed(2);
  document.getElementById('sb-crr').innerText = `CRR ${crr}`;

  const battingBody = document.querySelector('#batting-table tbody');
  battingBody.innerHTML = data.batting.map(b => {
    const sr = b.balls_faced > 0 ? ((b.runs / b.balls_faced) * 100).toFixed(1) : '0.0';
    const cls = b.player_id === data.innings.striker_id ? 'striker' : '';
    return `<tr class="${cls}"><td>${b.name}${b.status==='retired' ? ' (ret)' : b.status==='out' ? ' (out)' : ''}</td><td>${b.runs}</td><td>${b.balls_faced}</td><td>${b.fours}</td><td>${b.sixes}</td><td>${sr}</td></tr>`;
  }).join('');

  const bowlingBody = document.querySelector('#bowling-table tbody');
  bowlingBody.innerHTML = data.bowling.map(b => {
    const econ = b.overs_bowled > 0 ? (b.runs_conceded / b.overs_bowled).toFixed(2) : '0.00';
    return `<tr><td>${b.name}</td><td>${b.overs_bowled}</td><td>${b.runs_conceded}</td><td>${b.wickets}</td><td>${econ}</td></tr>`;
  }).join('');

  const eligibleRes = await fetch(`${API}/innings/${state.inningsId}/eligible-batsmen`);
  const eligible = (await eligibleRes.json()).eligible_player_ids;
  document.getElementById('striker-select').innerHTML = eligible.map(id =>
    `<option value="${id}" ${id === data.innings.striker_id ? 'selected' : ''}>${nameOf(id)}</option>`).join('');

  const bowlIds = data.bowling.map(b => b.player_id);
  document.getElementById('bowler-select').innerHTML = bowlIds.map(id =>
    `<option value="${id}" ${id === data.innings.bowler_id ? 'selected' : ''}>${nameOf(id)}</option>`).join('');

  renderThisOverBalls(data.innings);

  if (overJustCompleted) {
    promptNextBowler(data.bowling.map(b => b.player_id), data.innings.bowler_id);
  }

  checkInningsCompletion(data);
}

async function checkInningsCompletion(data) {
  if (state.inningsCompletionHandled) return;

  const matchRes = await fetch(`${API}/matches/${state.matchId}`);
  const match = await matchRes.json();
  const oversLimit = parseFloat(match.overs_limit);
  const oversDone = parseFloat(data.innings.overs_completed);

  const rosterSize = data.batting.length;
  const outCount = data.batting.filter(b => b.status === 'out').length;
  const allOut = rosterSize > 0 && outCount >= rosterSize - 1;
  const oversFinished = oversDone >= oversLimit;

  if (allOut || oversFinished) {
    state.inningsCompletionHandled = true;
    const reason = allOut ? 'All batsmen are out.' : 'Overs limit reached.';
    showInningsCompleteModal(reason);
  }
}

function showInningsCompleteModal(reason) {
  const container = document.getElementById('extra-modal-container');
  container.innerHTML = `
    <div class="modal-overlay">
      <div class="modal-sheet">
        <h3>Innings Complete</h3>
        <p class="helper-text">${reason} Ready to start the next innings?</p>
        <button class="btn btn-primary btn-full" onclick="startNextInnings()">Start Next Innings</button>
        <button class="btn btn-secondary btn-full" style="margin-top:6px;" onclick="closeExtraModal()">Not yet</button>
      </div>
    </div>`;
}

async function startNextInnings() {
  await fetch(`${API}/matches/innings/${state.inningsId}/complete`, { method: 'POST' });
  closeExtraModal();
  const battingTeamSelect = document.getElementById('innings-batting-team');
  const currentBattingTeam = document.getElementById('sb-batting-team').innerText.includes(document.getElementById('team-a-name')?.value || 'Team A') ? 'A' : 'B';
  const nextBattingTeam = currentBattingTeam === 'A' ? 'B' : 'A';
  document.getElementById('innings-batting-team').value = nextBattingTeam;
  state.inningsCompletionHandled = false;
  showView('setup');
  document.getElementById('start-innings-card').style.display = 'block';
  populateInningsSelectors();
}

function promptNextBowler(bowlIds, currentBowlerId) {
  const container = document.getElementById('extra-modal-container');
  container.innerHTML = `
    <div class="modal-overlay">
      <div class="modal-sheet">
        <h3>Over complete — pick next bowler</h3>
        <select id="next-bowler-select" class="field">
          ${bowlIds.map(id => `<option value="${id}" ${id === currentBowlerId ? 'selected' : ''}>${nameOf(id)}</option>`).join('')}
        </select>
        <button class="btn btn-primary btn-full" onclick="confirmNextBowler()">Confirm Bowler</button>
      </div>
    </div>`;
}

async function confirmNextBowler() {
  const newId = parseInt(document.getElementById('next-bowler-select').value);
  await fetch(`${API}/matches/innings/${state.inningsId}/change-bowler`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ new_bowler_id: newId })
  });
  closeExtraModal();
  refreshScorecard();
}

async function renderThisOverBalls(innings) {
  const oversInt = Math.floor(innings.overs_completed);
  const container = document.getElementById('this-over-balls');
  const res = await fetch(`${API}/innings/${state.inningsId}/over/${oversInt}/balls`);
  const balls = await res.json();
  if (balls.length === 0) {
    container.innerHTML = `<span style="font-size:12px; color:var(--sub);">Over ${oversInt + 1} — no balls yet</span>`;
    return;
  }
  container.innerHTML = balls.map(b => {
    let cls = 'runs', label = String(b.runs);
    if (b.is_wicket) { cls = 'wicket'; label = 'W'; }
    else if (b.extra_type === 'wide') { cls = 'extra'; label = 'Wd'; }
    else if (b.extra_type === 'no_ball') { cls = 'extra'; label = `Nb+${b.extra_runs}`; }
    else if (b.runs === 4) { cls = 'four'; }
    else if (b.runs === 6) { cls = 'six'; }
    return `<div class="ball-pill ${cls}">${label}</div>`;
  }).join('');
}

async function loadDailyStats() {
  const date = document.getElementById('stats-date').value;
  const url = date ? `${API}/stats/daily?date=${date}` : `${API}/stats/daily`;
  const res = await fetch(url);
  const rows = await res.json();
  document.querySelector('#daily-stats-table tbody').innerHTML = rows.map(r =>
    `<tr><td>${r.name}</td><td>${r.total_runs}</td><td>${r.balls_faced}</td><td>${r.wickets}</td></tr>`).join('');
}

async function loadOverallStats() {
  const res = await fetch(`${API}/stats/overall`);
  const rows = await res.json();
  document.querySelector('#overall-stats-table tbody').innerHTML = rows.map(r =>
    `<tr><td>${r.name}</td><td>${r.innings_played}</td><td>${r.total_runs}</td><td>${Math.round(r.strike_rate)}</td><td>${r.wickets}</td><td>${r.wins}-${r.losses}</td><td>${r.win_pct}%</td></tr>`).join('');
}

loadPlayers();
showView('setup');
